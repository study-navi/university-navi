# GitHub Pages反映手順

1. ZIPを展開する
2. 中身を `university-navi` リポジトリ直下にアップロードする
3. ルートに `index.html` がある状態にする
4. GitHub Pages の公開設定は main ブランチ / root
5. 公開URLを開く

## 注意
`index_shingaku_compass_...html` のような巨大HTMLを置くのではなく、
必ず `index.html` / `css` / `js` / `data` / `assets` の形で置いてください。

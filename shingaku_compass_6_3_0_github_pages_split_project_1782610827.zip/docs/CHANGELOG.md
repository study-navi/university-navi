# CHANGELOG

## 6.3.0
- 巨大な単体HTML形式を廃止
- GitHub Pages向けに index.html / css / js / data / assets へ分割
- 今後の更新対象を data/universities.json 中心に変更
- UIは名市大テンプレート型のまま固定

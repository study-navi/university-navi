# 進学コンパス 6.3.0 GitHub Pages分割構成版

## 今回の重要変更
巨大な単体HTMLをやめて、GitHub Pages向けの通常Webサイト構成にしました。

## 構成
- `index.html`：アプリ本体
- `css/style.css`：デザイン
- `js/`：アプリ動作
- `data/universities.json`：大学データ
- `data/universities.js`：互換用データ
- `assets/`：画像など

## メリット
- GitHub上で巨大HTML表示エラーが出にくい
- GitHub Pagesで公開しやすい
- 今後は基本的に `data/universities.json` を更新すればよい
- 500大学以上に増えても管理しやすい

## 現在の登録大学数
538大学

## 今後の更新ルール
- UIは原則変更しない
- `index.html` は固定
- `css/` と `js/` も原則固定
- 大学データは `data/universities.json` に追加
- 公式確認できた内容だけ登録
- 未確認項目は「未確認」として残す

## GitHub Pagesでの使い方
このZIPの中身をリポジトリ直下にアップロードしてください。
公開URLは通常、`https://study-navi.github.io/university-navi/` のようになります。

